
i=0
while i<=25:
    n = +(1 / (2 ** (i - 1)))
    i=i+1
print (n)


# OUTPUT 5.960464477539063e-08