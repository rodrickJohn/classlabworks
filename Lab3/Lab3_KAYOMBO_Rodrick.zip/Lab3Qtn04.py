
for n in range(26):
    n=+(1/(2**(n-1)))

print(n)

# OUTPUT 5.960464477539063e-08